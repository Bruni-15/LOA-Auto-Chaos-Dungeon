import pyautogui

while True:
    print(pyautogui.displayMousePosition())
